<script type="text/javascript">

function countyswitch(state){

//document.CALC.outputtext.value=""; //=clears text area

switch(state){
     case "AL":
      removeAllOptions();
      addOption('autauga','Autauga');
      addOption('baldwin','Baldwin');
      addOption('babour','Babour');
      addOption('bibb','Bibb');
      addOption('blount','Blount');
      addOption('bullock','Bullock');
      addOption('butler','Butler');
      addOption('calhoun','Calhoun');
      addOption('chambers','Chambers');
      addOption('cherokee','Cherokee');
      addOption('chilton','Chilton');
addOption('choctaw','Choctaw');
addOption('clarke','Clarke');
addOption('clay','Clay');
addOption('cleburne','Cleburne');
addOption('crenshaw','Crenshaw');
addOption('cullman','Cullman');
addOption('covington','Covington');
addOption('coffee','Coffee');
addOption('conecuh','Conecuh');
addOption('coosa','Coosa');
addOption('dale','Dale');
addOption('dallas','Dallas');
addOption('dekalb','De Kalb');
addOption('elmore','Elmore');
addOption('escambia','Escambia');
addOption('etowah','Etowah');
addOption('fayette','Fayette');
addOption('franklin','Franklin');
addOption('geneva','Geneva');
addOption('greene','Greene');
addOption('hale','Hale');
addOption('henry','Henry');
addOption('houston','Houston');
addOption('jackson','Jackson');
addOption('jefferson','Jefferson');
addOption('lamar','Lamar');
addOption('lauderdale','Lauderdale');
addOption('lee','Lee');
addOption('limestone','Limestone');
addOption('lowndes','Lowndes');
addOption('macon','Macon');
addOption('madison','Madison');
addOption('marengo','Marengo');
addOption('marshall','Marshall');
addOption('mobile','Mobile');
addOption('monroe','Monroe');
addOption('montogomery','Montogomery');
addOption('morgan','Morgan');
addOption('perry','Perry');
addOption('pickens','Pickens');
addOption('pike','Pike');
addOption('randolph','Randolph');
addOption('russell','Russell');
addOption('shelby','Shelby');
addOption('stclair','St. Clair');
addOption('sumter','Sumter');
addOption('talladega','Talladega');
addOption('tallapoosa','Tallapoosa');
addOption('walker','Walker');
addOption('washington','Washington');
addOption('wilcox','Wilcox');
addOption('winston','Winston');
     break;

     case "DE":
              removeAllOptions();
        addOption('kent','Kent');
        addOption('newcastle','New Castle');
        addOption('sussex','Sussex');

     break;


     case "MA":
      removeAllOptions();
        addOption('allothers','All Other Counties');
        addOption('duke','Duke');
        addOption('nantucket','Nantucket');
       

      break;

     case "MD":
      removeAllOptions();
      addOption('allegany','Allegany');
      addOption('annearundel','Anne Arundel');
      addOption('baltimore','Baltimore');
      addOption('baltimorecity','Baltimore City');
      addOption('calvert','Calvert');
      addOption('caroline','Caroline');
      addOption('carroll','Carroll');
      addOption('cecil','Cecil');
      addOption('charles','Charles');
      addOption('dorchester','Dorchester');
      addOption('frederick','Frederick');
      addOption('garrett','Garrett');
      addOption('harford','Harford');
      addOption('howard','Howard');
      addOption('kent','Kent');
      addOption('montgomery','Montgomery');
      addOption('princegeorge','Prince George');
      addOption('queenanne','Queen Anne');
      addOption('stmarys','St. Marys');
      addOption('somerset','Somerset');
      addOption('talbot','Talbot');
      addOption('washington','Washington');
      addOption('wicomico','Wicomico');
      addOption('worcester','Worcester');
      break;

     case "MN":
      removeAllOptions();
      addOption('hennepin','Hennepin');
      addOption('allothers','All Other Counties');
     break;

     case "MS":
              removeAllOptions();
         addOption('alcorn','Alcorn');
          addOption('amite','Amite');
          addOption('attala','Attala');
          addOption('benton','Benton');
          addOption('bolivar','Bolivar');
          addOption('calchoun','Calhoun');
        addOption('carroll','Carroll');
        addOption('chickasaw','Chickasaw');
        addOption('choctaw','Choctaw');
        addOption('claiborne','Claiborne');
        addOption('clarke','Clarke');
        addOption('clay','Clay');
        addOption('coahoma','Coahoma');
        addOption('copiah','Copiah');
        addOption('covington','Covington');
        addOption('desoto','De Soto');
        addOption('forrest','Forrest');
        addOption('franklin','Franklin');
        addOption('george','George');
        addOption('greene','Greene');
        addOption('grenada','Grenada');
        addOption('hancock','Hancock');
        addOption('harrison','Harrison');
addOption('hinds','Hinds');
addOption('holmes','Holmes');
addOption('humphreys','Humphreys');
addOption('issaquena','Issaquena');
addOption('itawamba','Itawamba');
addOption('jackson','Jackson');
addOption('jasper','Jasper');
addOption('jefferson','Jefferson');
addOption('jeffersondavis','Jefferson Davis');
addOption('jones','Jones');
addOption('kemper','Kemper');
addOption('lafayette','Lafayette');
addOption('lamar','Lamar');
addOption('lauderdale','Lauderdale');
addOption('lawrence','Lawrence');
addOption('leake','Leake');
addOption('lee','Lee');
addOption('leflore','Leflore');
addOption('lincoln','Lincoln');
addOption('lowndes','Lowndes');
addOption('madison','Madison');
addOption('marion','Marion');
addOption('marshall','Marshall');
addOption('monroe','Monroe');
addOption('montgomery','Montgomery');
addOption('neshoba','Neshoba');
addOption('newton','Newton');
addOption('noxubee','Noxubee');
addOption('oktibbeha','Oktibbeha');
addOption('panola','Panola');
addOption('pearlriver','Pearl River');
addOption('perry','Perry');
addOption('pike','Pike');
addOption('pontonoc','Pontotoc');
addOption('prentiss','Prentiss');
addOption('rankin','Rankin');
addOption('scott','Scott');
addOption('sharkey','Sharkey');
addOption('simpson','Simpson');
addOption('smith','Smith');
addOption('stone','Stone');
addOption('sunflower','Sunflower');
addOption('tallahatchie','Tallahatchie');
addOption('tate','Tate');
addOption('tippah','Tippah');
addOption('tishomingo','Tishomingo');
addOption('tunica','Tunica');
addOption('union','Union');
addOption('walthall','Walthall');
addOption('warren','Warren');
addOption('washington','Washington');
addOption('wayne','Wayne');
addOption('webster','Webster');
addOption('wilkinson','Wilkinson');
addOption('winston','Winston');
addOption('yalobusha','Yalobusha');
addOption('yazoo','Yazoo');

         break;
case"NJ":
removeAllOptions();
addOption('Atlantic','Atlantic');
addOption('Bergen','Bergen');
addOption('Burlington','Burlington');
addOption('Camden','Camden');
addOption('Cape May','Cape May');
addOption('Cumberland','Cumberland');
addOption('Essex','Essex');
addOption('Gloucester','Gloucester');
addOption('Hudson','Hudson');
addOption('Hunterdon','Hunterdon');
addOption('Mercer','Mercer');
addOption('Middlesex','Middlesex');
addOption('Monmouth','Monmouth');
addOption('Morris','Morris');
addOption('Ocean','Ocean');
addOption('Passaic','Passaic');
addOption('Salem','Salem');
addOption('Somerset','Somerset');
addOption('Sussex','Sussex');
addOption('Union','Union');
addOption('Warren','Warren');

  
break;         
         
     case "NY":

	//var load = window.open('http://www.smartgfecalculator.com/Widget/AutoLogin?clientKey=d5d9beb1-ed6d-476c-a777-06373cc3b6cd&officekey=aace1339-644d-4302-81b7-018ed3d79f67','','scrollbars=yes,menubar=yes,height=600,width=800,resizable=yes,toolbar=yes,location=no,status=no');



      removeAllOptions();
      addOption('albany','Albany');
      addOption('allegany','Allegany');
      addOption('bronx','Bronx');
      addOption('brooklyn','Brooklyn');
      addOption('broome','Broome');
      addOption('cattaraugus','Cattaraugus');
      addOption('cayuga','Cayuga');
      addOption('chautauqua','Chautauqua');
      addOption('chemung','Chemung');
      addOption('chenango','Chenango');
      addOption('clinton','Clinton');
      addOption('columbia','Columbia');
      addOption('cortland','Cortland');
      addOption('delaware','Delaware');
      addOption('dutchess','Dutchess');
      addOption('erie','Erie');
      addOption('essex','Essex');
      addOption('franklin','Franklin');
      addOption('fulton','Fulton');
      addOption('genesee','Genesee');
      addOption('greene','Greene');
      addOption('hamilton','Hamilton');
      addOption('herkimer','Herkimer');
      addOption('jefferson','Jefferson');
      addOption('kings','Kings');
      addOption('lewis','Lewis');
      addOption('livingston','Livingston');
      addOption('madison','Madison');
      addOption('manhattan','Manhattan');
      addOption('monroe','Monroe');
      addOption('montgomery','Montgomery');
      addOption('nassau','Nassau');
      addOption('newyork','New York');
      addOption('niagara','Niagara');
      addOption('oneida','Oneida');
      addOption('onondaga','Onondaga');
      addOption('ontario','Ontario');
      addOption('orange','Orange');
      addOption('orleans','Orleans');
      addOption('oswego','Oswego');
      addOption('otsego','Otsego');
      addOption('putnam','Putnam');
      addOption('queens','Queens');
      addOption('rensselaer','Rensselaer');
      addOption('richmond','Richmond');
      addOption('rockland','Rockland');
      addOption('stlawrence','St. Lawrence');
      addOption('saratoga','Saratoga');
      addOption('schenectady','Schenectady');
      addOption('schoharie','Schoharie');
      addOption('schuyler','Schuyler');
      addOption('seneca','Seneca');
      addOption('statenisland','Staten Island');
      addOption('steuben','Steuben');
      addOption('suffolk','Suffolk');
      addOption('sullivan','Sullivan');
      addOption('tioga','Tioga');
      addOption('tompkins','Tompkins');
      addOption('ulster','Ulster');
      addOption('warren','Warren');
      addOption('washington','Washington');
      addOption('wayne','Wayne');
      addOption('westchester','Westchester');
      addOption('wyoming','Wyoming');
      addOption('yates','Yates');
      break;

    case "PA":
      removeAllOptions();
      addOption('adams','Adams');
      addOption('allegheny','Allegheny');
      addOption('armstrong','Armstrong');
      addOption('beaver','Beaver');
      addOption('bedford','Bedford');
      addOption('berks','Berks');
addOption('blair','Blair');
addOption('bradford','Bradford');
addOption('bucks','Bucks');
addOption('butler','Butler');
addOption('cambria','Cambria');
addOption('cameron','Cameron');
addOption('carbon','Carbon');
addOption('centre','Centre');
addOption('chester','Chester');
addOption('clarion','Clarion');
addOption('clearfield','Clearfield');
addOption('clinton','Clinton');
addOption('columbia','Columbia');
addOption('crawford','Crawford');
addOption('cumberland','Cumberland');
addOption('dauphin','Dauphin');
addOption('delaware','Delaware');
addOption('elk','Elk');
addOption('erie','Erie');
addOption('fayette','Fayette');
addOption('forest','Forest');
addOption('franklin','Franklin');
addOption('fulton','Fulton');
addOption('greene','Greene');
addOption('huntingdon','Huntingdon');
addOption('indiana','Indiana');
addOption('jefferson','Jefferson');
addOption('juniata','Juniata');
addOption('lackawanna','Lackawanna');
addOption('lancaster','Lancaster');
addOption('lawrence','Lawrence');
addOption('lebanon','Lebanon');
addOption('lehigh','Lehigh');
addOption('luzerne','Luzerne');
addOption('lycoming','Lycoming');
addOption('mckean','McKean');
addOption('mercer','Mercer');
addOption('mifflin','Mifflin');
addOption('monroe','Monroe');
addOption('montgomery','Montgomery');
addOption('montour','Montour');
addOption('northampton','Northampton');
addOption('northumberland','Northumberland');
addOption('perry','Perry');
addOption('philadelphia','Philadelphia');
addOption('pike','Pike');
addOption('potter','Potter');
addOption('schuylkill','Schuylkill');
addOption('snyder','Snyder');
addOption('somerset','Somerset');
addOption('sullivan','Sullivan');
addOption('susquehanna','Susquehanna');
addOption('tioga','Tioga');
addOption('union','Union');
addOption('venango','Venango');
addOption('warren','Warren');
addOption('washington','Washington');
addOption('wayne','Wayne');
addOption('westmoreland','Westmoreland');
addOption('wyoming','Wyoming');
addOption('york','York');
      break;

      case "TN":
      removeAllOptions();
      addOption('davidson','Davidson');
      addOption('hamilton','Hamilton');
      addOption('knox','Knox');
      addOption('rutherford','Rutherford');
      addOption('shelby','Shelby');
      addOption('williamson','Williamson');
      addOption('allother','All other Counties');
      break;


     default:
      removeAllOptions();
     addOption('allcounties','All Counties');
}//end of switch

townSwitch();
}//end of county switch


</script>
