<?php
header('P3P: CP="CAO PSA OUR"');
session_start();

include('les_config.php');


if(!empty($_SESSION['Username']) && $_SESSION['LoggedIn'] == 1)  
{

  ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">
<head>
<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
<?php

if(preg_match('/(?i)msie [7-8]/',$_SERVER['HTTP_USER_AGENT'])==1)
{
?>
<link rel="stylesheet" href="css/GFE_old.css" type="text/css" />
<style>li{float:left;display:inline;}</style>
<?php
}
else{
?>
<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
<?php
}
?>

<meta charset="utf-8" />
<meta http-equiv="X-UA-Compatible" content="IE=edge"> 
<script src="http://code.jquery.com/jquery-1.9.1.js"></script>
<!--<script src="http://code.jquery.com/ui/1.10.3/query-ui.js"></script>-->
<script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
<?php
if(isset($_SESSION['state'])){echo '<script>$("document").ready(function(){$("#state").val("'.$_SESSION['state'].'");})</script>';}
if(isset($_SESSION['county'])){echo '<script>$("document").ready(function(){$("#county").val("'.$_SESSION['county'].'");})</script>';}
if(isset($_SESSION['township'])){echo '<script>$("document").ready(function(){$("#township").val("'.$_SESSION['township'].'");})</script>';}
?>

<!-- <link rel="stylesheet" href="stylesheets/datepicker.css" />   -->
<script>$(function() {    $( "#datepicker" ).datepicker();  });  </script>
<!--[if lt IE 9]>
<script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script>
<script src="js/respond.js"></script>
<![endif]-->
<script>

//function addOption(value, text ) {
//  var optn = document.createElement("OPTION");
//  optn.text = text;
//  optn.value = value;
//  document.CALC.county.options.add(optn);
//}
//
//function addTownship(value, text ) {
//  var optn = document.createElement("OPTION");
//  optn.text = text;
//  optn.value = value;
//  document.CALC.township.options.add(optn);
//}
//
//function removeAllOptions()
//{
//while(document.CALC.county.options.length >0)
//{document.CALC.county.remove(0);}
//}
//
//function clearTownships()
//{
//while(document.CALC.township.options.length >0)
//{document.CALC.township.remove(0);}
//}

function fetchcounties(state){
        $.ajax({
                 url:"fetchcounty.php",
                 type: "post",
                 async:false,
                 data:{
                    'state':state
                    },
                 success: function(data) 
	        {
                 $("#county").html(data);
                 fetchtownships($('#county').val(),$('#state').val());
                 
	        }});
        
        
    }
    
    function fetchtownships(county,state){
        
        $.ajax({
                 url:"fetchtownship.php",
                 type: "post",
                 async:false,
                 data:{
                    'county':county,
                    'state': state
                    },
                 success: function(data) 
	        {
                 $("#township").html(data);
	        }});
        
        
    }
    
function OrderTitle()
{
if (document.CALC.state.value == "NJ" || document.CALC.state.value == "NY"){ window.location = "ordertitle_nj.php";}
else {window.location = "ordertitle.php";}
                  
}



function ValidateGFE(){
  var result="";
  
     //Sets default off for mansion tax inicator
    document.CALC.mansion.value = "";
    
  if(document.CALC.purchase_price.value >1000000 && document.CALC.loantype[0].checked == true && document.CALC.state.value=="NJ")
  {
    var mansion=confirm("Please click 'Ok' if Property is 1-3 Family home");
      
    if(mansion==true){
      document.CALC.mansion.value = "Yes";
    }
  }
  
  //checks loan amount
  if(document.CALC.loan_amount.value >=0 && document.CALC.loan_amount.value < 100000000){}
  else {alert("Please enter a valid loan amount"); document.CALC.loan_amount.value=0; return false;}
  
  //checks purchase price
  if(document.CALC.purchase_price.value >=0 &&  document.CALC.purchase_price.value < 100000000){}
  else {alert("Please enter a valid purchase price"); document.CALC.purchase_price.value=0; return false;}
  
  //checks existing debt
  if(document.CALC.exdebt.value >=0 && document.CALC.exdebt.value < 100000000){}
  else {alert("Please enter a valid existing debt amount"); document.CALC.exdebt.value=0; return false;}
  


}// end form validation funtion

function ClearGFE(){
  clearTownships();
  removeAllOptions();
  document.CALC.state.value = "NA";
  document.CALC.purchase_price.value = 0;
  document.CALC.exdebt.value = 0;
  document.CALC.loan_amount.value = 0;
  document.CALC.filename.value = "";
  document.CALC.loanid.value = "";
  
  document.CALC.TitleOrderOnly.checked = false;
  document.CALC.FirstTime.checked = false;
  document.CALC.loantype[0].checked = true;
}

</script>
</head>

<body style="background: #efeee9;">

<div class="container">
  
  <?php
if(preg_match('/(?i)msie [7-8]/',$_SERVER['HTTP_USER_AGENT'])==1)
{
?>
<ul>
<li>
 <?php if($gfe=="1"){?><li class="active"><a href="GFE_main.php" class="navbutton">GFE</a></li><?php } ?>
 <?php if($ac=="1"){?><li><a href="AC_main.php" class="navbutton">Affordability</a></li><?php } ?>
 <?php if($nyc=="1"){?><li><a href="CEMA_main.php" class="navbutton">New York</a></li><?php } ?>
 <?php if($ctic=="1"){?><li><a href="COMM_main.php" class="navbutton">Commercial</a></li><?php } ?>
 
<!--<li><a href="AC_main.php" class="navbutton">Affordability</a></li>
<li><a href="COMM_main.php" class="navbutton">Commercial</a></li>
<li><a href="CEMA_main.php" class="navbutton">New York Calculator</a></li>-->
<li><a href="history.php" class="navbutton">Search History</a></li>
<li><a href="ordertitle.php" class="navbutton">Order Title</a></li>
<li><a href="myprofile.php" class="navbutton">My Profile</a></li>
<li><a href="logout.php" class="navbutton">Log Out</a></li>
</ul>  
<?php
}
else{
?>

<nav class="navbar navbar-default" role="navigation">
  <!-- Brand and toggle get grouped for better mobile display -->
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
      <span class="sr-only">Toggle navigation</span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="http://lssoftwaresolutions.com/" target="_blank"><img class="img-responsive" src="./Images/lode_star_logo.png" style="height:50px;width: 102px" alt="Responsive image"></a>
  </div>

  <!-- Collect the nav links, forms, and other content for toggling -->
  <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav"> 
 <?php if($gfe=="1"){?><li class="active"><a href="GFE_main.php" >GFE</a></li><?php } ?>
 <?php if($ac=="1"){?><li><a href="AC_main.php" class="navbutton">Affordability</a></li><?php } ?>
 <?php if($nyc=="1"){?><li><a href="CEMA_main.php" class="navbutton">New York</a></li><?php } ?>
 <?php if($ctic=="1"){?><li><a href="COMM_main.php" class="navbutton">Commercial</a></li><?php } ?>
 
    </ul>
    <ul class="nav navbar-nav navbar-right">
      <li><a href="ordertitle.php">Order Title</a></li>
      <li><a href="myprofile.php">My Profile</a></li>
      <li><a href="history.php">My Searches</a></li>
      <li><a href="logout.php">Log Out</a></li>
    </ul>
  </div><!-- /.navbar-collapse -->

</nav>

<?php
}
?>


</div>

<div class='middle'>
  <div class="container">
       <p STYLE= margin-left:15px;font-family:arial;color:grey;font-size:30px;">GFE Fee Calculator
        <br/>
        <!-- #Implement-->
        <!--Change URL path to direct to client file folder -->
	<form name="CALC" method="post" action="GFE_results.php" target="GFE_iframe" onsubmit="return ValidateGFE()">
	<table class="table table-hover" STYLE=margin-left:15px border="0" cellspacing="2" cellpadding="10">

	 <tr><td colspan="1"><b>Loan Type:</td>
	<td width="256"><input type="radio" name="purpose" value="1" <?php if($_SESSION['purpose']==1){echo "checked";}else{echo "checked";}?> /> Purchase &nbsp;
	<input type="radio" name="purpose" value="0" <?php if($_SESSION['purpose']==0){echo "checked";}?> /> Refinance
	</b></td> 
        <td><b>Purchase Price:</b></td><td><input type="text" name="purchase_price" size=10 value="<?php if(isset($_SESSION['purchase_price'])){echo $_SESSION['purchase_price'];} else{echo"0";} ?>" ></td></tr>
	<tr><td></td><td><input type="checkbox" id="TitleOrderOnly" name="TitleOrderOnly" <?php if($_SESSION['TitleOrderOnly']=="on"){echo "CHECKED";}?>>Title Order Only (NJ & NY)</td>
	<td><b>Loan Amount:</b></td><td><input type="text" name="loan_amount" size=10 value="<?php if(isset($_SESSION['loan_amount'])){echo $_SESSION['loan_amount'];} else{echo"0";} ?>" ></td></tr>	
	<tr><td><b>State:</b></td>
	<td><select id="state" name="state" value="NA" onchange= "fetchcounties(this.value)">
	<option value="NA">Please Select a State</option>
      <?php   
         foreach($GLOBALS['states'] as $state)
        {
            
            echo '<option value="'.$state.'">'.$state.'</option>';
        }
        
        ?>
	<!-- <option value="AK" <?php if($_SESSION['state']=='AK'){echo "selected";}?>>AK</option>
         <option value="AL" <?php if($_SESSION['state']=='AL'){echo "selected";}?>>AL</option>
         <option value="AR" <?php if($_SESSION['state']=='AR'){echo "selected";}?>>AR</option>
         <option value="AZ" <?php if($_SESSION['state']=='AZ'){echo "selected";}?>>AZ</option>
         <option value="CA" <?php if($_SESSION['state']=='CA'){echo "selected";}?>>CA</option>
         <option value="CO" <?php if($_SESSION['state']=='CO'){echo "selected";}?>>CO</option>
         <option value="CT" <?php if($_SESSION['state']=='CT'){echo "selected";}?>>CT</option>
         <option value="DC" <?php if($_SESSION['state']=='DC'){echo "selected";}?>>DC</option>
         <option value="DE" <?php if($_SESSION['state']=='DE'){echo "selected";}?>>DE</option>
         <option value="FL" <?php if($_SESSION['state']=='FL'){echo "selected";}?>>FL</option>
         <option value="GA" <?php if($_SESSION['state']=='GA'){echo "selected";}?>>GA</option>
         <option value="HI" <?php if($_SESSION['state']=='HI'){echo "selected";}?>>HI</option>
         <option value="IA" <?php if($_SESSION['state']=='IA'){echo "selected";}?>>IA</option>
	 <option value="ID" <?php if($_SESSION['state']=='ID'){echo "selected";}?>>ID</option>
	 <option value="IL" <?php if($_SESSION['state']=='IL'){echo "selected";}?>>IL</option>
	 <option value="IN" <?php if($_SESSION['state']=='IN'){echo "selected";}?>>IN</option>
         <option value="KS" <?php if($_SESSION['state']=='KS'){echo "selected";}?>>KS</option>
         <option value="KY" <?php if($_SESSION['state']=='KY'){echo "selected";}?>>KY</option>
         <option value="LA" <?php if($_SESSION['state']=='LA'){echo "selected";}?>>LA</option>
         <option value="MA" <?php if($_SESSION['state']=='MA'){echo "selected";}?>>MA</option>
         <option value="MD" <?php if($_SESSION['state']=='MD'){echo "selected";}?>>MD</option>
         <option value="ME" <?php if($_SESSION['state']=='ME'){echo "selected";}?>>ME</option>
         <option value="MI" <?php if($_SESSION['state']=='MI'){echo "selected";}?>>MI</option>
         <option value="MN" <?php if($_SESSION['state']=='MN'){echo "selected";}?>>MN</option>
         <option value="MO" <?php if($_SESSION['state']=='MO'){echo "selected";}?>>MO</option>
         <option value="MS" <?php if($_SESSION['state']=='MS'){echo "selected";}?>>MS</option>
         <option value="MT" <?php if($_SESSION['state']=='MT'){echo "selected";}?>>MT</option>
         <option value="NC" <?php if($_SESSION['state']=='NC'){echo "selected";}?>>NC</option>
         <option value="ND" <?php if($_SESSION['state']=='ND'){echo "selected";}?>>ND</option>
         <option value="NE" <?php if($_SESSION['state']=='NE'){echo "selected";}?>>NE</option>
         <option value="NH" <?php if($_SESSION['state']=='NH'){echo "selected";}?>>NH</option>
         <option value="NJ" <?php if($_SESSION['state']=='NJ'){echo "selected";}?>>NJ</option>
         <option value="NM" <?php if($_SESSION['state']=='NM'){echo "selected";}?>>NM</option>
         <option value="NV" <?php if($_SESSION['state']=='NV'){echo "selected";}?>>NV</option>
         <option value="NY" <?php if($_SESSION['state']=='NY'){echo "selected";}?>>NY</option>
         <option value="OH" <?php if($_SESSION['state']=='OH'){echo "selected";}?>>OH</option>
         <option value="OK" <?php if($_SESSION['state']=='OK'){echo "selected";}?>>OK</option>
         <option value="OR" <?php if($_SESSION['state']=='OR'){echo "selected";}?>>OR</option>
         <option value="PA" <?php if($_SESSION['state']=='PA'){echo "selected";}?>>PA</option>
         <option value="RI" <?php if($_SESSION['state']=='RI'){echo "selected";}?>>RI</option>
         <option value="SC" <?php if($_SESSION['state']=='SC'){echo "selected";}?>>SC</option>
         <option value="SD" <?php if($_SESSION['state']=='SD'){echo "selected";}?>>SD</option>
         <option value="TN" <?php if($_SESSION['state']=='TN'){echo "selected";}?>>TN</option>
         <option value="TX" <?php if($_SESSION['state']=='TX'){echo "selected";}?>>TX</option>
         <option value="UT" <?php if($_SESSION['state']=='UT'){echo "selected";}?>>UT</option>
         <option value="VA" <?php if($_SESSION['state']=='VA'){echo "selected";}?>>VA</option>
         <option value="VT" <?php if($_SESSION['state']=='VT'){echo "selected";}?>>VT</option>
         <option value="WA" <?php if($_SESSION['state']=='WA'){echo "selected";}?>>WA</option>
         <option value="WI" <?php if($_SESSION['state']=='WI'){echo "selected";}?>>WI</option>
         <option value="WV" <?php if($_SESSION['state']=='WV'){echo "selected";}?>>WV</option>
         <option value="WY" <?php if($_SESSION['state']=='WY'){echo "selected";}?>>WY</option>-->
	 </select> </td>
	<td> <b>Existing Debt:</b><br/>(Refis in FL,MD & NJ only)</td><td><input type="text" name="exdebt" size=10 value=<?php if(isset($_SESSION['exdebt'])){echo $_SESSION['exdebt'];} else{echo"0";} ?>></td></tr>
	
        <tr><td><b>County: </b></td>
	<td><select name="county" id="county" onchange= "fetchtownships(this.value,state.value)">
	 <option value="NA">Please select a county</option> 
	 </select></td>
	
        <td><b> LoanID: </b></td>
        <td><input type="text" name="loanid" size=20 value="<?= $_SESSION['loanid'] ?>"></td>
	</tr>
	
        <tr><td><b>Township: </b></td><td> <select name="township" id="township"  >
	 <option value="NA">Please select a township</option> 
	</select></td>
          
	<td><b>File Name: </b></td><td><input type="text" name="filename" size=20 value="<?= $_SESSION['filename'] ?>"></td>
	</tr>
	<tr><td>
        <!--<b>Zipcode:</b></td><td> <input name="zip_code" id="zip_code"  >-->
	</td>
        <td><input type="checkbox" name="FirstTime" value="FirstTime" <?php if($_SESSION['FirstTime']=="FirstTime"){echo "CHECKED";}?>>First Time Home Buyer</td>
	<td><input type="checkbox" name="PrincipleResidence" value="PrincipleResidence" >Principle Residence</td></tr>
        
	<tr><td><input type="submit" class="btn btn-default"  name="CalculateRate" value= "Calculate Rate" /></td>
	<td><input type="submit"  class="btn btn-default"   name="ReissueRate" value= "Reissue Rate" />
        <input type="submit" class="btn btn-default"  name="EmailQuote" value= "Email Quote"/></td>
	<td><input type="submit" class="btn btn-default" name="PrintHUD" value= "Preview HUD"/></td>
	<td><input type="button" class="btn btn-default"  name="command"  value= "Order Title" onclick=OrderTitle() />
        <input type="submit" class="btn btn-default" name="PrintQuote" value="Print"  />
        <input type="hidden" name="mansion" size=20 value=""></td></tr>
	</table>
        </form><br/>
	
        <!-- #Implement -->
        <!--Change URL path to direct to client file folder -->
	<iframe name="GFE_iframe" src="GFE_results.php" width="700" height="550" seamless style="border:none"></iframe>
	</div>
        </div>

	<!-- End of Rate calculator -->


 <script type="text/javascript">

//resets county and town fields when session variable is pulled in
  //window.onload=countyswitch();
  //window.onload=townSwitch();

</script>

<?php	

} else{

$_SESSION['lastref'] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
$_SESSION['target']="GFE";

// #Implement
if(!isset($_SESSION['lastref']))
{
  $_SESSION['lastref']=$path."GFE_main.php";
}

 echo "<meta http-equiv='refresh' content='0;url=Login/index.php'>";
 
}
?>

</body>
</html>
